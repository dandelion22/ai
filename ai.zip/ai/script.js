

var totalScore = 0;
var score = 0;
var i = "";
var msgBox =""
var gameRound = 0;
var tryNumber = ""
var card = [];




document.getElementsByClassName("")

var deck = [

    {"indexOrder":  0, "number":  1, "card":  "Ace", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "A"},
    {"indexOrder":  1, "number":  2, "card":  "Two", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 2},
    {"indexOrder":  2, "number":  3, "card":  "Three", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 3},
    {"indexOrder":  3, "number":  4, "card":  "Four", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 4},
    {"indexOrder":  4, "number":  5, "card":  "Five", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 5},
    {"indexOrder":  5, "number":  6, "card":  "Six", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 6},
    {"indexOrder":  6, "number":  7, "card":  "Seven", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 7},
    {"indexOrder":  7, "number":  8, "card":  "Eight", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 8},
    {"indexOrder":  8, "number":  9, "card":  "Nine", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 9},
    {"indexOrder":  9, "number":  10, "card":  "Ten", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 10},
    {"indexOrder":  10, "number":  11, "card":  "Jack", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "J"},
    {"indexOrder":  11, "number":  12, "card":  "Queen", "kind": "Royal", "parity": "Even", "parityIndex": 2, "display": "Q"},
    {"indexOrder":  12, "number":  13, "card":  "King", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "K"}
  

];

var suit = [
    {"suit": "Spades", "color": "Black"},
    {"suit": "Harts", "color": "Red" },
    {"suit": "Clubs", "color": "Black" },
    {"suit": "Diamonds", "color": "Red" },
    ];



function selectCard() {

     
    bxMsg("A card has been randomly selected.", "Select a color please.", "info");
    
    var i = ""
    var tellTale = "" 

    i= Math.floor(Math.random() * 13); 
    card[0] = deck[i];
    i = Math.floor(Math.random() * 4 );
    card[0].suit = suit[i].suit
    card[0].color = suit[i].color 

  
    
    
    document.getElementById("score").innerHTML = score;
    document.getElementById("start").style.display = "none";
    document.getElementById("description").innerHTML = "<b>Card selected, select a color<b>";
  
    document.getElementById("choice1").style.display = "inline";
    
    document.getElementById("start").style.display = "none";

    tellTale = "The card is the "+card[0].card +" of "+ card[0].suit +".";
    console.log(tellTale)

    document.getElementById("cardDisplay").style.display = "inline";
    document.getElementById("progressCard").src = "img/blank.png";


};


function selectColor(color) {

  
    if (color == card[0].color) {
       
        score += 20; 

        bxMsg("Correct you scored 20 points.","Now select a suit.", "success");
 
  
    } else {
        bxMsg("Incorrect.", "Select a suit please.", "error")
    }

    if(card[0].color == "Black") {
                   
        
        document.getElementById("Harts").style.display = "none"
        document.getElementById("Diamonds").style.display = "none"
        document.getElementById("Spades").style.display = "inline"
        document.getElementById("Clubs").style.display = "inline"

         } else if (card[0].color == "Red") {
                   
        document.getElementById("Spades").style.display = "none"
        document.getElementById("Clubs").style.display = "none"
        document.getElementById("Harts").style.display = "inline"
        document.getElementById("Diamonds").style.display = "inline"
         }

   
    document.getElementById("choice1").style.display = "none";
    document.getElementById("choice2").style.display = "inline";
    document.getElementById("score").innerHTML = score;
    document.getElementById("progressCard").src = "img/"+card[0].color+".png";         
    document.getElementById("description").innerHTML = "<b>Select a suit<b>";
   
}


function selectSuit(suit) {

    if (suit == card[0].suit){
        
        score += 20; 

        if (score >= 20) {
            
            bxMsg("Correct 20 points more.","Select royalty or number?", "success");      

        } else {

            bxMsg("Correct you scored 20 points.","Select royalty or number?", "success");
        
        } 

    } else {

            bxMsg("Incorrect.", "Select royalty or number?", "error")
  
    }
 
 document.getElementById("choice2").style.display = "none";
 document.getElementById("choice3").style.display = "inline";
 document.getElementById("progressCard").src = "img/"+card[0].suit+".png";
 document.getElementById("score").innerHTML = score;
 document.getElementById("description").innerHTML = "<b>Select royalty or number.";

}

function selectKind(kind) {

    if(kind == card[0].kind) {

        score += 20;

        if (score >= 20) {

        bxMsg("Correct 20 points more.","Select odd or even?", "success");  

                  
        } else {

            bxMsg("Correct you scored 20 points.","Select odd or even?", "success");

                   }

    } else{
    
        bxMsg("Incorrect.", "Select odd or even?", "error")

    }


 
    document.getElementById("score").innerHTML = score;
    document.getElementById("description").innerHTML = "<b>Select odd or even.<b>";
    document.getElementById("choice3").style.display = "none";
    document.getElementById("choice4").style.display = "inline";

}



function selectParity(oddity){


    if (oddity == card[0].parity){

    score += 20;
    bxMsg("Correct you scored 20 points.","Final phase select a card.", "success");
   
    
    
    } else {


        bxMsg("Incorrect.", "Final phase select a card.", "error")
   
       
    }

    if (card[0].parity == "Odd")  {
                  
        document.getElementById("Two").style.display = "none"; 
        document.getElementById("Four").style.display = "none"; 
        document.getElementById("Six").style.display = "none"; 
        document.getElementById("Eight").style.display = "none"; 
        document.getElementById("Ten").style.display = "none"; 
        document.getElementById("Queen").style.display = "none"; 

        document.getElementById("Ace").style.display = "inline";             
        document.getElementById("Three").style.display = "inline";
        document.getElementById("Five").style.display = "inline"; 
        document.getElementById("Seven").style.display = "inline";  
        document.getElementById("Nine").style.display = "inline";   
        document.getElementById("Jack").style.display = "inline";    
        document.getElementById("King").style.display = "inline";
        

        }

    else if (card[0].parity == "Even")  {
        
        document.getElementById("Ace").style.display = "none";             
        document.getElementById("Three").style.display = "none";
        document.getElementById("Five").style.display = "none"; 
        document.getElementById("Seven").style.display = "none";  
        document.getElementById("Nine").style.display = "none";   
        document.getElementById("Jack").style.display = "none";    
        document.getElementById("King").style.display = "none";

        document.getElementById("Two").style.display = "inline"; 
        document.getElementById("Four").style.display = "inline"; 
        document.getElementById("Six").style.display = "inline"; 
        document.getElementById("Eight").style.display = "inline"; 
        document.getElementById("Ten").style.display = "inline"; 
        document.getElementById("Queen").style.display = "inline";  


    }

    document.getElementById("score").innerHTML = score;
    document.getElementById("description").innerHTML = "<b>Select a card.<b>";
    document.getElementById("choice4").style.display = "none";
    document.getElementById("choice5").style.display = "inline";

     
    var bdeck = document.getElementsByClassName("ccard");
    for (var i =0; i < bdeck.length; i+=1){
     bdeck[i].src = "img/"+card[0].suit+".png";}
       
}

function pickCard(finalCard) {


    if(finalCard == card[0].card) {

        score += 20;
               
        document.getElementById("score").innerHTML = score;      
        document.getElementById("choice5").style.display = "none"; 
        document.getElementById("finalCard").style.display = "block";
        document.getElementById("finalCard").innerHTML = card[0].display; 
        document.getElementById("description").style.display = "none";  

        bxMsg("Correct!","The final score for this round is "+score+".", "success");
              setTimeout(continuePlaying, 3000 );     
            
    } else {

        var scoreByThree = Math.floor(score/3);
        document.getElementById(finalCard).style.display = "none"
        bigQuestion("Incorrect","For "+scoreByThree+" points less on your score would you like to try again?", "error", tryAgain , finishRound);
        
    
    }  
}


function tryAgain() {
    score -= Math.floor(score/3);
    document.getElementById("score").innerHTML = score;
}


   
function finishRound() {
   
    bxMsg("Round complete.","The final score for this round is "+score+".", "info");
    setTimeout(continuePlaying, 3000 );  

}

function continuePlaying() {

    gameRound += 1;
    bigQuestion("Round "+gameRound+" complete.","Would you like to play another round?", "info", playAgain, endGame);
    document.getElementById("choice5").style.display = "none"; 
   
   }

function endGame(){

    totalScore += score;
    bxMsg("Game Over","The final score for this sesion is "+totalScore, "info");
    document.getElementById("choice5").style.display = "none"; 
   
}



function playAgain() {

    document.getElementById("start").style.display = "inline"; 
    document.getElementById("cardDisplay").style.display = "none";
    totalScore += score;
    score = 0;
    document.getElementById("score").innerHTML = score;
    document.getElementById("totalScore").innerHTML = totalScore;
    document.getElementById("finalCard").style.display = "none";
    document.getElementById("finalCard").innerHTML = ""; 
    document.getElementById("description").style.display = "block"; 
  

}



function bxMsg(a,b,c){
     swal(a,b,c);
}


function bigQuestion(bgMsg, txt, icn, callBack1, callBack2) {

    swal({
            title: bgMsg,
            text: txt,
            icon: icn,
            buttons: ["No", "Ok"],
    }).then((keepPlaying) => {

        if (keepPlaying) {

            callBack1();

    } else {

           
            callBack2();

        }

    })

}










