
var score = 0;
var i = "";
var msgBox =""
var gamePhase = "";
var tryNumber = ""
var card = [];

var deck = [

    {"indexOrder":  0, "number":  1, "card":  "Ace", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "A"},
    {"indexOrder":  1, "number":  2, "card":  "Two", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 2},
    {"indexOrder":  2, "number":  3, "card":  "Three", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 3},
    {"indexOrder":  3, "number":  4, "card":  "Four", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 4},
    {"indexOrder":  4, "number":  5, "card":  "Five", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 5},
    {"indexOrder":  5, "number":  6, "card":  "Six", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 6},
    {"indexOrder":  6, "number":  7, "card":  "Seven", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 7},
    {"indexOrder":  7, "number":  8, "card":  "Eight", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 8},
    {"indexOrder":  8, "number":  9, "card":  "Nine", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 9},
    {"indexOrder":  9, "number":  10, "card":  "Ten", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 10},
    {"indexOrder":  10, "number":  11, "card":  "Jack", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "J"},
    {"indexOrder":  11, "number":  12, "card":  "Queen", "kind": "Royal", "parity": "Even", "parityIndex": 2, "display": "Q"},
    {"indexOrder":  12, "number":  13, "card":  "King", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "K"}
  

];

var suit = [
    {"suit": "Spades", "color": "Black"},
    {"suit": "Harts", "color": "Red" },
    {"suit": "Clubs", "color": "Black" },
    {"suit": "Dimonds", "color": "Red" },
    ];



function selectCard() {

     
    var i = ""
    var tellTale = "" 

    i= Math.floor(Math.random() * 13); 
    card[0] = deck[i];
    i = Math.floor(Math.random() * 4 );
    card[0].suit = suit[i].suit
    card[0].color = suit[i].color 

    tellTale = "The card is the "+ card[0].card + " of " + card[0].suit + ".";
    console.log(tellTale)

alert("The system has randomly selected a card. Choose a color please.")

document.getElementById("card").innerHTML = "<b>Card selected<b>"
document.getElementById("score").innerHTML = score;

document.getElementById("start").style.display = "none";

document.getElementById("description").innerHTML = "<b>Choose a color<b>";



};


function selectColor(color) {

    if (color == card[0].color) {

        alert("Correct you scored 20 points. Now chose a suit.")
        score += 20;
        document.getElementById("score").innerHTML = score;
        
        document.getElementById("progressCard").src = "img/"+card[0].color+".png";

              

        document.getElementById("description").innerHTML = "<b>Choose a suit<b>";
        

            if(card[0].color == "Black") {

            document.getElementById("Spades").disabled = false;
            document.getElementById("Clubs").disabled = false;
            document.getElementById("Harts").id = "inactiveHarts"
            document.getElementById("Dimonds").id = "inactiveDimonds"

            } else if (card[0].color == "Red") {

        
            document.getElementById("Harts").disabled = false;
            document.getElementById("Dimonds").disabled = false;
            document.getElementById("Spades").id = "inactiveSpades";
            document.getElementById("Clubs").id = "inactiveClubs" ;
    
            }
  
    }
   
    else {

        alert("Incorrect, you receive no points. Well... select a suit please.")

        
        document.getElementById("progressCard").src = "img/"+card[0].color+".png";
        document.getElementById("description").innerHTML = "<b>Choose a suit<b>";
        
        
        if(
            card[0].color == "Black"
        ) {

            document.getElementById("Spades").disabled = false;
            document.getElementById("Clubs").disabled = false;
            document.getElementById("Harts").id = "inactiveHarts"
            document.getElementById("Dimonds").id = "inactiveDimonds"


        } else if (card[0].color == "Red") {

    
            document.getElementById("Harts").disabled = false;
            document.getElementById("Dimonds").disabled = false;
            document.getElementById("Spades").id = "inactiveSpades";
            document.getElementById("Clubs").id =  "inactiveClubs" ;



    }
       
    }
}


function selectSuit(suit) {

 
 if (suit == card[0].suit){

          

    if (score == 20) {

        alert("Very well done, you scored 20 points more. Now choose... royalty or number?")

    } else {

        alert("Correct you scored 20 points. Now chose royalty or number?")
    }

    score += 20;


    document.getElementById("progressCard").src = "img/"+card[0].suit+".png";

    document.getElementById("score").innerHTML = score;

 

    document.getElementById("description").innerHTML = "<b>Choose royalty or number.";

   
    

 } else {

    
    alert("Incorrect, you receive no points. Bad luck, choose royalty or number.")
 
   
    document.getElementById("description").innerHTML = "<b>Choose royalty or number.";
    document.getElementById("progressCard").src = "img/"+card[0].suit+".png";
   
   

 }

}

function selectKind(kind) {

    if(kind == card[0].kind) {

        
    if (score > 20) {

        alert("Men you are on fire! you scored 20 points more. To the next round. Select odd or even?")
    
    } else {

        alert("Correct you scored 20 points. Now chose odd or even?")
    }

    score += 20;
    document.getElementById("score").innerHTML = score;
   
    document.getElementById("description").innerHTML = "<b>Choose odd or even.<b>";
 
    


} else{
    

        alert("Too bad. Select odd or even.")
       
        document.getElementById("description").innerHTML = "<b>Choose odd or even.<b>";
     
   
 
}


}

function selectParity(oddity){


    if (oddity == card[0].parity){
    
    alert("Correct! You are very close to the end. Final phase chose a card. ")
    
    score += 20;
    
    document.getElementById("score").innerHTML = score;
   
    
    
  
    // document.getElementById("Odd").disabled = true;
    //document.getElementById("Even").disabled = true;
    document.getElementById("choice4").style.display = "none";
   
    document.getElementById("description").innerHTML = "<b>Choose a card.<b>";
    
    
        if(card[0].parity == "Odd") {
    
           
            //document.getElementById("Ace").disabled = false;
            document.getElementById("Two").style.display = "none"; 
            //document.getElementById("Three").disabled = false;
            document.getElementById("Four").style.display = "none"; 
            //document.getElementById("Five").disabled = false;
            document.getElementById("Six").style.display = "none"; 
            //document.getElementById("Seven").disabled = false;
            document.getElementById("Eight").style.display = "none"; 
            //document.getElementById("Nine").disabled = false;
            document.getElementById("Ten").style.display = "none"; 
            //document.getElementById("Jack").disabled = false;
            document.getElementById("Queen").style.display = "none"; 
            //document.getElementById("King").disabled = false; 
       
 
        }
    
        else  {
    
            
            document.getElementById("Ace").style.display = "none";             
            document.getElementById("Three").style.display = "none";
            document.getElementById("Five").style.display = "none"; 
            document.getElementById("Seven").style.display = "none";  
            document.getElementById("Nine").style.display = "none";   
            document.getElementById("Jack").style.display = "none";    
            document.getElementById("King").style.display = "none";

            //document.getElementById("Two").disabled = false;
            //document.getElementById("Four").disabled = false;
            //document.getElementById("Six").disabled = false;          
            //document.getElementById("Eight").disabled = false;     
            //document.getElementById("Ten").disabled = false;     
            //document.getElementById("Queen").disabled = false;
            
          


    
          
    
    
        }
    
    
    } else {
    
    alert("Incorrect. Well final phase, Choose a card.")

    

//document.getElementById("Odd").disabled = true;
//document.getElementById("Even").disabled = true;
document.getElementById("choice4").style.display = "none";  
  
   
    document.getElementById("description").innerHTML = "<b>Choose a card.<b>";
    
    if(card[0].parity == "Odd") {

       //document.getElementById("Ace").disabled = false;
        document.getElementById("Two").style.display = "none"; 
       //document.getElementById("Three").disabled = false;
        document.getElementById("Four").style.display = "none"; 
        //document.getElementById("Five").disabled = false;
        document.getElementById("Six").style.display = "none"; 
        //document.getElementById("Seven").disabled = false;
        document.getElementById("Eight").style.display = "none"; 
        //document.getElementById("Nine").disabled = false;
        document.getElementById("Ten").style.display = "none"; 
        //document.getElementById("Jack").disabled = false;
        document.getElementById("Queen").style.display = "none"; 
        //document.getElementById("King").disabled = false;
        
            }
        
            else if (card[0].parity == "Even") {
        
          
            document.getElementById("Ace").style.display = "none";  
            //document.getElementById("Two").disabled = false;
            document.getElementById("Three").style.display = "none";    
            //document.getElementById("Four").disabled = false;
            document.getElementById("Five").style.display = "none";  
            //document.getElementById("Six").disabled = false;
            document.getElementById("Seven").style.display = "none";  
            //document.getElementById("Eight").disabled = false;
            document.getElementById("Nine").style.display = "none";  
            //document.getElementById("Ten").disabled = false;
            document.getElementById("Jack").style.display = "none";  
            //document.getElementById("Queen").disabled = false;
            document.getElementById("King").style.display = "none";  
    
        
        
            }
    
    
    }
    
    }

function pickCard(finalCard) {



    if(finalCard != card[0].card) {
        

        var scoreByThree = Math.floor(score/3);

        document.getElementById(finalCard).className = "choices";
        msgBox = "Incorrect. For "+scoreByThree+" points less on your score would you like to try again?";
        var tryAgain = confirm(msgBox);

        if (tryAgain == true) {

            score -= Math.floor(scoreByThree);
            document.getElementById("score").innerHTML = score;

        }

        else 
                {
                    alert("Too bad, your final score for this round  is "+ score)
                  
                    document.getElementById("choice5").style.display = "none";    
                    
                    var again = confirm("Would you like to play again?")
                    if (again == true ){
                    playAgain();}

                   
                }
       

       


    } else {

    
        score += 20;
        document.getElementById("score").innerHTML = score;
        alert("Correct! your final score for this round is "+ score)         
        document.getElementById("choice5").style.display = "none";   
        
        

        var again = confirm("Would you like to play again?")
        if (again == true ){
        playAgain();
    }
        
        


          
    }

}



function playAgain() {

    document.getElementById("start").style.display = "block";

    if (document.getElementById("inactiveSpades")&&document.getElementById("inactiveSpades") )

    {

        document.getElementById("inactiveClubs").id = "Clubs";
        document.getElementById("inactiveSpades").id = "Spades";

    } else {

        document.getElementById( "inactiveHarts").id = "Harts";
        document.getElementById("inactiveDimonds").id = "Dimonds"; 

    }


   // document.getElementById("Ace").disabled = true;
    document.getElementById("Two").className = "bcard" 
    //document.getElementById("Three").disabled = true;
    document.getElementById("Four").className = "bcard" 
    //document.getElementById("Five").disabled = true;
    document.getElementById("Six").className = "bcard" 
    //document.getElementById("Seven").disabled = true;
    document.getElementById("Eight").className = "bcard" 
    //document.getElementById("Nine").disabled = true;
    document.getElementById("Ten").className = "bcard" 
    //document.getElementById("Jack").disabled = true;
    document.getElementById("Queen").className = "bcard" 
    //document.getElementById("King").disabled = true;



    document.getElementById("Ace").className = "bcard"  
   // document.getElementById("Two").disabled = true;
    document.getElementById("Three").className = "bcard"  
    //document.getElementById("Four").disabled = true;
    document.getElementById("Five").className = "bcard"  
    //document.getElementById("Six").disabled = true;
    document.getElementById("Seven").className = "bcard"  
    //document.getElementById("Eight").disabled = true;
    document.getElementById("Nine").className = "bcard" 
    //document.getElementById("Ten").disabled = true;
    document.getElementById("Jack").className = "bcard"  
    //document.getElementById("Queen").disabled = true;
    document.getElementById("King").className = "bcard"  


    document.getElementById("choice4").style.display = "inline";




    document.getElementById("progressCard").src = "img/blank.png"
    document.getElementById("card").innerHTML = ""



    
   

    




}






$(document).ready(function(){

    $("#start").click(function() {
        $("#choice1").show();
        $("#cardDisplay").show();
        $("#start").hide();
    })

    $(".bcolor").click(function() {
        $("#choice1").hide();
        $("#choice2").show();  
      
    })

    $(".bsuit").click(function() {
        $("#choice2").hide();
        $("#choice3").show();
    })

    $(".bkind").click(function() {
        $("#choice3").hide();
        $("#choice4").show();
    })

    $(".bparity").click(function() {
        $("#choice4").hide();
        $("#choice5").show();
    })
      

});