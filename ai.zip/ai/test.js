
//var card = [];

var deck = [

    {"indexOrder":  0, "number":  1, "card":  "Ace", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "A"},
    {"indexOrder":  1, "number":  2, "card":  "Two", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 2},
    {"indexOrder":  2, "number":  3, "card":  "Three", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 3},
    {"indexOrder":  3, "number":  4, "card":  "Four", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 4},
    {"indexOrder":  4, "number":  5, "card":  "Five", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 5},
    {"indexOrder":  5, "number":  6, "card":  "Six", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 6},
    {"indexOrder":  6, "number":  7, "card":  "Seven", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 7},
    {"indexOrder":  7, "number":  8, "card":  "Eight", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 8},
    {"indexOrder":  8, "number":  9, "card":  "Nine", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 9},
    {"indexOrder":  9, "number":  10, "card":  "Ten", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 10},
    {"indexOrder":  10, "number":  11, "card":  "Jack", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "J"},
    {"indexOrder":  11, "number":  12, "card":  "Queen", "kind": "Royal", "parity": "Even", "parityIndex": 2, "display": "Q"},
    {"indexOrder":  12, "number":  13, "card":  "King", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "K"},
    [  {"suit": "Spades", "color": "Black"},
    {"suit": "Harts", "color": "Red" },
    {"suit": "Clubs", "color": "Black" },
    {"suit": "Dimonds", "color": "Red" },]



];

var suit = [

    {"suit": "Spades", "color": "Black"},
    {"suit": "Harts", "color": "Red" },
    {"suit": "Clubs", "color": "Black" },
    {"suit": "Dimonds", "color": "Red" },


];



function selectCard() {

    
 
    var i = ""
    

    i= Math.floor(Math.random() * 13); 
    card[0] = deck[i];
    i = Math.floor(Math.random() * 4 );
    card[0].suit = suit[i].suit
    card[0].color = suit[i].color 
    console.log(card)

alert("The system has randomly selected a card. Choose a color please.")
document.getElementById("card").innerHTML = "<b>Card selected<b>"
document.getElementById("score").innerHTML = score;

document.getElementById("start").disabled = true;
document.getElementById("description").innerHTML = "<b>Choose a color<b>";
document.getElementsByClassName ("bcolor").disabled = false;




};





/*
var deck = [
    {"indexOrder":  0, "number":  1, "card":  "Ace", "suit":  "Spades", "color": "Black", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "A"},
    {"indexOrder":  1, "number":  2, "card":  "Two", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 2},
    {"indexOrder":  2, "number":  3, "card":  "Three", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 3},
    {"indexOrder":  3, "number":  4, "card":  "Four", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 4},
    {"indexOrder":  4, "number":  5, "card":  "Five", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 5},
    {"indexOrder":  5, "number":  6, "card":  "Six", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 6},
    {"indexOrder":  6, "number":  7, "card":  "Seven", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 7},
    {"indexOrder":  7, "number":  8, "card":  "Eight", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 8},
    {"indexOrder":  8, "number":  9, "card":  "Nine", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 9},
    {"indexOrder":  9, "number":  10, "card":  "Ten", "suit":  "Spades", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 10},
    {"indexOrder":  10, "number":  11, "card":  "Jack", "suit":  "Spades", "color": "Black", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "J"},
    {"indexOrder":  11, "number":  12, "card":  "Queen", "suit":  "Spades", "color": "Black", "kind": "Royal", "parity": "Even", "parityIndex": 2, "display": "Q"},
    {"indexOrder":  12, "number":  13, "card":  "King", "suit":  "Spades", "color": "Black", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "K"},
    {"indexOrder":  13, "number":  1, "card":  "Ace", "suit":  "Harts", "color": "Red", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "A"},
    {"indexOrder":  14, "number":  2, "card":  "Two", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 2},
    {"indexOrder":  15, "number":  3, "card":  "Three", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 3},
    {"indexOrder":  16, "number":  4, "card":  "Four", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 4},
    {"indexOrder":  17, "number":  5, "card":  "Five", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 5},
    {"indexOrder":  18, "number":  6, "card":  "Six", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 6},
    {"indexOrder":  19, "number":  7, "card":  "Seven", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 7},
    {"indexOrder":  20, "number":  8, "card":  "Eight", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 8},
    {"indexOrder":  21, "number":  9, "card":  "Nine", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 9},
    {"indexOrder":  22, "number":  10, "card":  "Ten", "suit":  "Harts", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 10},
    {"indexOrder":  23, "number":  11, "card":  "Jack", "suit":  "Harts", "color": "Red", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "J"},
    {"indexOrder":  24, "number":  12, "card":  "Queen", "suit":  "Harts", "color": "Red", "kind": "Royal", "parity": "Even", "parityIndex": 2, "display": "Q"},
    {"indexOrder":  25, "number":  13, "card":  "King", "suit":  "Harts", "color": "Red", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "K"},
    {"indexOrder":  26, "number":  1, "card":  "Ace", "suit":  "Clubs", "color": "Black", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "A"},
    {"indexOrder":  27, "number":  2, "card":  "Two", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 2},
    {"indexOrder":  28, "number":  3, "card":  "Three", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 3},
    {"indexOrder":  29, "number":  4, "card":  "Four", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 4},
    {"indexOrder":  30, "number":  5, "card":  "Five", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 5},
    {"indexOrder":  31, "number":  6, "card":  "Six", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 6},
    {"indexOrder":  32, "number":  7, "card":  "Seven", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 7},
    {"indexOrder":  33, "number":  8, "card":  "Eight", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 8},
    {"indexOrder":  34, "number":  9, "card":  "Nine", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 9},
    {"indexOrder":  35, "number":  10, "card":  "Ten", "suit":  "Clubs", "color": "Black", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 10},
    {"indexOrder":  36, "number":  11, "card":  "Jack", "suit":  "Clubs", "color": "Black", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "J"},
    {"indexOrder":  37, "number":  12, "card":  "Queen", "suit":  "Clubs", "color": "Black", "kind": "Royal", "parity": "Even", "parityIndex": 2, "display": "Q"},
    {"indexOrder":  38, "number":  13, "card":  "King", "suit":  "Clubs", "color": "Black", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "K"},
    {"indexOrder":  39, "number":  1, "card":  "Ace", "suit":  "Dimonds", "color": "Red", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "A"},
    {"indexOrder":  40, "number":  2, "card":  "Two", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 2},
    {"indexOrder":  41, "number":  3, "card":  "Three", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 3},
    {"indexOrder":  42, "number":  4, "card":  "Four", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 4},
    {"indexOrder":  43, "number":  5, "card":  "Five", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 5},
    {"indexOrder":  44, "number":  6, "card":  "Six", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 6},
    {"indexOrder":  45, "number":  7, "card":  "Seven", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 7},
    {"indexOrder":  46, "number":  8, "card":  "Eight", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 8},
    {"indexOrder":  47, "number":  9, "card":  "Nine", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Odd", "parityIndex": 1, "display": 9},
    {"indexOrder":  48, "number":  10, "card":  "Ten", "suit":  "Dimonds", "color": "Red", "kind": "Number", "parity": "Even", "parityIndex": 2, "display": 10},
    {"indexOrder":  49, "number":  11, "card":  "Jack", "suit":  "Dimonds", "color": "Red", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "J"},
    {"indexOrder":  50, "number":  12, "card":  "Queen", "suit":  "Dimonds", "color": "Red", "kind": "Royal", "parity": "Even", "parityIndex": 2, "display": "Q"},
    {"indexOrder":  51, "number":  13, "card":  "King", "suit":  "Dimonds", "color": "Red", "kind": "Royal", "parity": "Odd", "parityIndex": 1, "display": "K"}
    
    

];


function selectCard () {

i = Math.floor(Math.random() * 52 );

document.getElementById("card").innerHTML = "<b>Card selected<b>"

alert("The system has randomly selected a card. Choose a color please.")

document.getElementById("score").innerHTML = score;

//card = deck[i].card +" of "+ deck[i].suit + " the color is " + deck[i].color + " the kind is " + deck[i].kind + " and parity is " + deck[i].parity

//console.log(card)

    document.getElementById("start").disabled = true;
    document.getElementById("description").innerHTML = "<b>Choose a color<b>";
    document.getElementById("color1").disabled = false;
    document.getElementById("color2").disabled = false;
} */


var again = confirm("Would you like to play again?")

if (again == true ){

    playAgain();
}