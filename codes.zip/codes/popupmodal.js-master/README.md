# popupmodal.js
### A pure and simple javascript popup modal plugin. :)
Tired of the old looking browser default's popup modal?  
Well then, this is what you need!! :D  
